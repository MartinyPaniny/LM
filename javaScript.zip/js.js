function funcion(cadena,booleano,funcion,arrayNum)
{
    if((typeof cadena == "string")&&(typeof booleano == "boolean")&&( typeof funcion == "function")&&(Array.isArray(arrayNum)))
    {
        if(booleano)
        {
            let producto = 1
            cadena.forEach(n =>
                producto = producto * n                
            )
            if(producto >100)
            {

                if(arrayNum.includes("a"))
                {
                    console.log("la 'a' no está permitida")
                }
                else
                 console.log("muy bien, no has usado la 'a'");
            }
        else
        {
            console.log("El resultado de tu array es insuficiente para comprobar la cadena")
        }
        }
        else
        {
            funcion();
        }
    }
    else
    console.log("error")
}

funcion("hola mundo", false, () => { console.log("Se acabó el juego"); }, [1, 2, 3, 4,5,6,7,8,8,2,1,5]);

