let alumnos = 
[
    {nombre: 'Juan', edad: 25},
    {nombre:'Ana',edad: 30},
    {nombre: 'Pedro', edad: 40}
];

let alumnos2 = alumnos.map(alumno => {let curso = prompt(`Indica el nombre del curso de ${alumno.nombre}:`)
let asignaturas = prompt(`Indica el nombre de las asignaturas de ${alumno.nombre} separadas por "-":`).split("-");
return{ ...alumno,curso: curso, asignaturas: asignaturas};});


console.log(alumnos2);