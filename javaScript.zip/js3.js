function Buscar(nombresa, nombresb)
{
    let coincidencia = 0;
    nombresa.forEach(nombre =>{if(nombresb.includes(nombre))
coincidencia += 1});

    if(coincidencia > 0)
        console.log("Alguna coincidencia");
    else
        console.log("Ninguna coincidencia");
}

let arrayNombres1 = ["Carla","Mario"]
let arrayNombres2 = ["Maria", "Rocio", "Aitana", "Carolina", "Mario","Luigi"]

Buscar(arrayNombres1,arrayNombres2)