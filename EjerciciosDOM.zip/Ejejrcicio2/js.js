fetch('msj.txt')
  .then(response => response.text())
  .then(texto => {
    const lineas = texto.trim().split('\n');
    const contenedor = document.getElementById('chat');

    let fechaMostrada = false;

    lineas.forEach(linea => 
    {
      if (linea.startsWith('#')) 
        {
          if (!fechaMostrada) 
            {
              const fechaL = linea.replace('#', '').trim();
              const fechaDiv = document.createElement('div');
              fechaDiv.textContent = fechaL;
              fechaDiv.classList.add('fecha'); 
              contenedor.appendChild(fechaDiv);
              fechaMostrada = true; 
            }
          return;
        }

      const tipo = linea.startsWith('A:') ? 'izquierda' : 'derecha';
      const contenido = linea.replace(/^A:|^B:/, '').trim();

      const mensaje = document.createElement('div');
      mensaje.classList.add('mensaje', tipo);
      mensaje.textContent = contenido;
      contenedor.appendChild(mensaje);
    });
  });