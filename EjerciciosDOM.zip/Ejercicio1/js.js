fetch('biblioteca.xml')
  .then(response => response.text())
  .then(xmlString => {
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlString, "text/xml");
    mostrarLibrerias(xmlDoc);
  });

function mostrarLibrerias(xmlDoc) {
  const librerias = xmlDoc.getElementsByTagName("libreria");

  for (let libreria of librerias) {
    const nombre = libreria.getElementsByTagName("nombre")[0].textContent;
    const libros = libreria.getElementsByTagName("libro");

    const h2 = document.createElement("h2");
    h2.textContent = `Librería: ${nombre}`;
    document.body.appendChild(h2);

    const tabla = document.createElement("table");
    const header = `
      <tr>
        <th>ISBN</th>
        <th>Título</th>
        <th>Autor</th>
        <th>Editorial</th>
        <th>Año</th>
        <th>Web</th>
        <th>Precio (€)</th>
      </tr>
    `;
    tabla.innerHTML = header;

    let precios = Array.from(libros).map(libro =>
      parseFloat(libro.getElementsByTagName("precio")[0].textContent)
    );
    const precioMin = Math.min(...precios);

    for (let libro of libros) {
      const ISBN = libro.getElementsByTagName("ISBN")[0].textContent;
      const titulo = libro.getElementsByTagName("titulo")[0].textContent;
      const autor = libro.getElementsByTagName("autor")[0].textContent;
      const editorial = libro.getElementsByTagName("editorial")[0].textContent;
      const fecha = libro.getElementsByTagName("fechaPublicacion")[0].textContent;
      const web = libro.getElementsByTagName("paginaWeb")[0].textContent;
      const precio = parseFloat(libro.getElementsByTagName("precio")[0].textContent);

      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${ISBN}</td>
        <td>${titulo}</td>
        <td>${autor}</td>
        <td>${editorial}</td>
        <td>${fecha}</td>
        <td><a href="https://${web}" target="_blank">${web}</a></td>
        <td class="${precio === precioMin ? 'barato' : ''}">${precio}</td>
      `;
      tabla.appendChild(row);
    }

    document.body.appendChild(tabla);
  }
}